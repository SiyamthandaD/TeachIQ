from flask import Flask, request, jsonify, render_template
import google.generativeai as genai
import os

app = Flask(__name__, 
            static_folder='../static',
            template_folder='../static/templates')

# Configure Gemini
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
MODEL_NAME = "gemini-2.5-flash-preview-05-20"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/studyGuides')
def study_guides():
    return render_template('studyGuides.html')

@app.route('/documentation')
def documentation():
    return render_template('documentation.html')

@app.route('/documentation2')
def documentation2():
    return render_template('documentation2.html')

@app.route('/facebook')
def facebook():
    return render_template('facebook.html')

@app.route('/linkedin')
def linkedin():
    return render_template('linkedIn.html')

@app.route('/twitter')
def twitter():
    return render_template('twitter.html')

@app.route('/youtube')
def youtube():
    return render_template('youtube.html')

@app.route('/generate-content', methods=['POST'])
def generate_content():
    try:
        data = request.get_json()
        prompt = f"""
        Generate {data.get('contentType', '')} on {data.get('topic', '')}
        for {data.get('gradeLevel', '')} students in {data.get('subjectArea', '')}.
        Details: {data.get('details', '')}
        Complexity: {data.get('complexity', 'intermediate')}
        Format: {data.get('format', 'bullet_points')}
        """
        
        model = genai.GenerativeModel(MODEL_NAME)
        response = model.generate_content(prompt)
        return jsonify({"content": response.text})
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run()